%RAINFALL-RUNOFF MODEL MODEL (GR4J) BY TARIK BENKACI (1998-2017)
% and N. DECHEMI 
%Optimisation of Rainfall Runoff Model : Conceptual GR4J model (CEMAGREF-IRSTEA), 
%the version used in this Package is that developed by Perrin 2000 & Perrin  et al. 2003.
% OPTIMISATION METHODS: DETERMINISTICS METHODS WITH MANY ALGORITHMS
%in the Optimisation Models there is:  DETERMINISTICS METHODS
%    1 - --METHODES DETERMINISTES-- DETERMINISTICS_METHODS'),
%    2 - --METHODE PAR SOLVER--OPTIMISATION BY SOLVER'),
%    3 - --METHODE: DIRECT SEARCH_PATTERN SERACH--'),
%    4 - --METHODE STOCHASTIQUE--Stocahstic Method: Simulated annealing (SA):

%References of GR4J Model and Criterion Assessment:
%Makhlouf, Z., 1994. Compl�ments sur le mod�le pluie-d�bit GR4J et essai d�estimation de ses param�tres. Thesis (PhD). Paris University, XI Orsay.
%Perrin, C., 2000. Vers une am�lioration d�un mod�le global pluie-d�bit au travers d�une approche comparative. Thesis (PhD). Grenoble, France, 530 p.
%Perrin, C., Michel, C. and Andr�assian, V., 2003. Improvement of a parsimonious model for streamflow simulation. Journal of Hydrology, 279, 275-289
%Nash, J. and Sutcliffe, J.V., 1970. River flow forecasting through conceptual models. Part I -A discussion of principles. Journal of Hydrology, 27(3), 282-290.


clear all; 

Optim_GR4J
% thus the code execute optimisation Process to found best parameters of
% Conceptual GR4J model, with 4 parameters
%after optimisation the model displays and save the results in GR4J.xls results
%and RESULTS Text file
%Finally after optimisation the model can simulate new runoff values with
%GR4J_SIM
% Good Modelling



