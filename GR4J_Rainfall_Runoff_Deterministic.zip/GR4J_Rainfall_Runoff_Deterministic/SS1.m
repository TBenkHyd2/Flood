function SS1 = SS1(I,C);
% Function calculates time delay for HU1 of GR4J Model

fI = I;
    if fI <= 0., 
        SS1=0.;
    elseif fI >= C,
            SS1=1.;
    elseif fI <= C,
                SS1=(fI/C)^(2.5);
    end;
