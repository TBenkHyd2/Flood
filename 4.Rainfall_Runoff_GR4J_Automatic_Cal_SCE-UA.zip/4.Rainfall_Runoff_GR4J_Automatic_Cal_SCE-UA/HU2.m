function [x] = HU2(x,C,NH,NPX);
% Function calculates time delay according GR4J model

for k = 1:2*NH,
    x(NPX + k + NH) = SS2(k,x(4))-SS2(k-1,x(4));
end;