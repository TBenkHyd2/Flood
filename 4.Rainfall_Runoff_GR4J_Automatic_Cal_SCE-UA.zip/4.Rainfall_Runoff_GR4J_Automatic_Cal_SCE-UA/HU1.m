function [x] = HU1(x,C,NH,NPX);
% Function calculates time delay according GR4J model
for k = 1:NH,
    x(NPX + k) = SS1(k,x(4))- SS1(k-1,x(4));
end;